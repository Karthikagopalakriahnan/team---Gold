// src/pages/AddItem.jsx
import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { updateInventory } from "../../redux/slices/inventorySlice";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { addInventoryItem, getInventory } from "../../api/api";
import BarcodeScannerComponent from "react-qr-barcode-scanner"; // ✅ new import

const AddItem = () => {
  const { inventory } = useSelector((state) => state.inventory);
  const { isAuthenticated } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  const [formData, setFormData] = useState({
    id: "",
    productName: "",
    category: "",
    supplier: "",
    weight: "",
    purity: "",
    stockQuantity: "",
    pricePerGram: "",
    pricePerUnit: "",
    makingCharge: "",
    wastage: "",
    sellingPrice: "",
    lowStockAlert: 5,
    dateAdded: new Date().toLocaleDateString("en-GB").replace(/\//g, "/"),
  });
  const [error, setError] = useState("");
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [categoryInput, setCategoryInput] = useState({ parent: "", child: "" });
  const [categories, setCategories] = useState([
    {
      parent: "Jewelry",
      children: ["Ring", "Necklace", "Bracelet", "Earrings", "Pendant", "Chain"],
    },
  ]);

  // ✅ new scanner state
  const [openScanner, setOpenScanner] = useState(false);
  const [cameraError, setCameraError] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setError("");
  };

  const handleCategoryInputChange = (e) => {
    setCategoryInput({
      ...categoryInput,
      [e.target.name]: e.target.value,
    });
  };

  const handleAddCategory = (e) => {
    e.preventDefault();
    if (!categoryInput.parent || !categoryInput.child.trim()) {
      toast.error("Please select a parent category and enter a child category name.");
      return;
    }
    const newCategories = categories.map((cat) => {
      if (cat.parent === categoryInput.parent) {
        if (cat.children.includes(categoryInput.child.trim())) {
          toast.error("Category already exists under this parent.");
          return cat;
        }
        return { ...cat, children: [...cat.children, categoryInput.child.trim()] };
      }
      return cat;
    });
    setCategories(newCategories);
    setFormData((prev) => ({
      ...prev,
      category: `${categoryInput.parent} > ${categoryInput.child.trim()}`,
    }));
    setCategoryInput({ parent: "", child: "" });
    setShowCategoryModal(false);
    toast.success("Category added successfully!");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.id ||
      !formData.productName ||
      !formData.weight ||
      !formData.purity ||
      !formData.stockQuantity
    ) {
      setError("Please fill all required fields.");
      toast.error("Please fill all required fields.");
      return;
    }

    try {
      await addInventoryItem({
        id: formData.id,
        productName: formData.productName,
        category: formData.category || "General",
        supplier: formData.supplier || "Local Supplier",
        weight: parseFloat(formData.weight),
        purity: formData.purity,
        stockQuantity: parseInt(formData.stockQuantity, 10),
        pricePerGram: parseFloat(formData.pricePerGram) || 0,
        pricePerUnit: parseFloat(formData.pricePerUnit) || 0,
        makingCharge: parseFloat(formData.makingCharge) || 0,
        wastage: parseFloat(formData.wastage) || 0,
        sellingPrice: parseFloat(formData.sellingPrice) || 0,
        lowStockAlert: parseInt(formData.lowStockAlert, 10) || 5,
        dateAdded: new Date().toISOString().split("T")[0],
      });

      toast.success("✅ Product added successfully to database!");

      const res = await getInventory();
      dispatch(updateInventory(res.data || []));

      setTimeout(() => navigate("/inventory"), 1500);
    } catch (err) {
      console.error("Error adding product:", err);
      toast.error("❌ Failed to add product to database.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-white rounded-lg shadow-lg p-6 relative">
        <button
          type="button"
          onClick={() => navigate("/inventory")}
          className="absolute top-4 right-9 text-gray-500 hover:text-gray-700 text-3xl font-bold"
        >
          &times;
        </button>
        <h2 className="text-2xl font-bold mb-4 text-center">Add New Product</h2>

        {error && (
          <div
            className={`p-3 rounded mb-4 ${
              error.includes("successfully")
                ? "bg-green-100 text-green-800 border border-green-300"
                : "bg-red-100 text-red-800 border border-red-300"
            } text-center`}
          >
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="border p-4 rounded">
            <h3 className="font-semibold mb-2">Product Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex flex-col">
                <label htmlFor="id" className="mb-1 font-medium">
                  Barcode/SKU *
                </label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    id="id"
                    name="id"
                    value={formData.id}
                    onChange={handleChange}
                    className="border p-2 rounded flex-1"
                    required
                  />

                  {/* ✅ Scanner Button + Modal */}
                  <button
                    type="button"
                    onClick={() => setOpenScanner(true)}
                    className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 font-medium"
                  >
                    Scan
                  </button>

                  {openScanner && (
                    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
                      <div className="bg-white p-4 rounded-lg shadow-lg w-[90%] md:w-[400px] text-center">
                        <h2 className="font-semibold mb-3">📸 Scan Barcode / QR Code</h2>

                        <div className="border rounded overflow-hidden">
                          <BarcodeScannerComponent
                            width={350}
                            height={250}
                            onUpdate={(err, result) => {
                              if (result) {
                                setFormData((prev) => ({ ...prev, id: result.text }));
                                toast.success(`Scanned: ${result.text}`);
                                setOpenScanner(false);
                              } else if (err) {
                                console.error("Scanner error:", err);
                                setCameraError("Camera access denied or unavailable");
                              }
                            }}
                          />
                        </div>

                        {cameraError && <p className="text-red-500 mt-2">{cameraError}</p>}

                        <button
                          onClick={() => setOpenScanner(false)}
                          className="mt-4 bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
                        >
                          Close
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col">
                <label htmlFor="productName" className="mb-1 font-medium">
                  Product Name *
                </label>
                <input
                  type="text"
                  id="productName"
                  name="productName"
                  value={formData.productName}
                  onChange={handleChange}
                  className="border p-2 rounded"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div className="flex flex-col">
                <label htmlFor="category" className="mb-1 font-medium">
                  Category
                </label>
                <div className="flex space-x-2">
                  <select
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className="border p-2 rounded flex-1"
                  >
                    <option value="">Select Category</option>
                    {categories.flatMap((parentCat) =>
                      parentCat.children.map((child) => (
                        <option
                          key={`${parentCat.parent} > ${child}`}
                          value={`${parentCat.parent} > ${child}`}
                        >
                          {`${parentCat.parent} > ${child}`}
                        </option>
                      ))
                    )}
                  </select>
                  <button
                    type="button"
                    onClick={() => setShowCategoryModal(true)}
                    className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 font-medium"
                  >
                    Add Category
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Rest of your layout unchanged */}
          <div className="border p-4 rounded">
            <h3 className="font-semibold mb-2">Physical Properties</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex flex-col">
                <label htmlFor="weight" className="mb-1 font-medium">
                  Weight (grams) *
                </label>
                <input
                  type="number"
                  id="weight"
                  name="weight"
                  value={formData.weight}
                  onChange={handleChange}
                  className="border p-2 rounded"
                  step="0.1"
                  required
                />
              </div>
              <div className="flex flex-col">
                <label htmlFor="purity" className="mb-1 font-medium">
                  Purity *
                </label>
                <select
                  id="purity"
                  name="purity"
                  value={formData.purity}
                  onChange={handleChange}
                  className="border p-2 rounded"
                  required
                >
                  <option value="">Select Purity</option>
                  <option value="18K">18K</option>
                  <option value="22K">22K</option>
                  <option value="24K">24K</option>
                </select>
              </div>
              <div className="flex flex-col">
                <label htmlFor="stockQuantity" className="mb-1 font-medium">
                  Stock Quantity *
                </label>
                <input
                  type="number"
                  id="stockQuantity"
                  name="stockQuantity"
                  value={formData.stockQuantity}
                  onChange={handleChange}
                  className="border p-2 rounded"
                  min="0"
                  required
                />
              </div>
            </div>
          </div>

          {/* Pricing section remains unchanged */}
          <div className="border p-4 rounded">
            <h3 className="font-semibold mb-2">Pricing Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {[
                "pricePerGram",
                "pricePerUnit",
                "makingCharge",
                "wastage",
                "sellingPrice",
                "lowStockAlert",
              ].map((key) => (
                <div className="flex flex-col" key={key}>
                  <label htmlFor={key} className="mb-1 font-medium capitalize">
                    {key.replace(/([A-Z])/g, " $1")}
                  </label>
                  <input
                    type="number"
                    id={key}
                    name={key}
                    value={formData[key]}
                    onChange={handleChange}
                    className="border p-2 rounded"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end space-x-4 pt-4 border-t">
            <button
              type="button"
              onClick={() => navigate("/inventory")}
              className="bg-gray-500 text-white px-6 py-2 rounded hover:bg-gray-600 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-yellow-500 text-white px-6 py-2 rounded hover:bg-yellow-600 font-medium"
            >
              Add Product
            </button>
          </div>
        </form>
      </div>

      <ToastContainer />
    </div>
  );
};

export default AddItem;

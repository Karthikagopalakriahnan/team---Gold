import React from 'react';

const recentActivities = [
  {
    title: 'Gold ring 22K purchase order history',
    time: '2 hours ago',
    tag: 'Purchase',
    amount: '₹12,500',
  },
  {
    title: 'Gold Bracelet 24K purchase order history',
    time: '4 hours ago',
    tag: 'Purchase',
    amount: '₹25,000',
  },
  {
    title: 'Total billing History',
    time: '1 day ago',
    tag: 'Billing',
    amount: '',
  },
];

const tagColors = {
  Purchase: 'bg-gray-100 text-gray-800',
  Billing: 'bg-blue-100 text-blue-800',
};

const RecentActivities = () => {
  return (
    <div className="bg-white shadow-md rounded-lg p-6 w-full">
      <h2 className="text-xl font-semibold mb-4">Recent Activities</h2>
      <ul className="divide-y divide-gray-200">
        {recentActivities.map((activity, index) => (
          <li key={index} className="py-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-900">{activity.title}</p>
              <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
            </div>

            <div className="flex flex-col items-end space-y-1">
              <span
                className={`text-xs px-2 py-1 rounded-full font-medium ${tagColors[activity.tag] || 'bg-gray-100 text-gray-800'}`}
              >
                {activity.tag}
              </span>

              {activity.amount && (
                <span className="text-sm font-semibold text-yellow-600">
                  {activity.amount}
                </span>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RecentActivities;


import React from "react";
import { ArrowUp, ArrowDown, Minus, Star } from "lucide-react";

const TopSellingItems = () => {
  const items = [
    {
      rank: 1,
      name: "Gold Chain 22K",
      category: "Chains",
      sold: 12,
      amount: 24000,
      trend: "up",
    },
    {
      rank: 2,
      name: "Gold Necklaces 18K",
      category: "Rings",
      sold: 8,
      amount: 32000,
      trend: "up",
    },
    {
      rank: 3,
      name: "Silver Earrings",
      category: "Earrings",
      sold: 15,
      amount: 18000,
      trend: "stable",
    },
    {
      rank: 4,
      name: "Gold Bracelet 24K",
      category: "Bracelets",
      sold: 6,
      amount: 15000,
      trend: "down",
    },
  ];

  const trendStyles = {
    up: { color: "text-green-600", bg: "bg-green-100", icon: <ArrowUp className="w-4 h-4" /> },
    down: { color: "text-red-600", bg: "bg-red-100", icon: <ArrowDown className="w-4 h-4" /> },
    stable: { color: "text-yellow-600", bg: "bg-yellow-100", icon: <Minus className="w-4 h-4" /> },
  };

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-center gap-2 mb-4">
        <Star className="w-5 h-5 text-yellow-500" />
        <h3 className="text-lg font-semibold">Top Selling Items</h3>
      </div>

      <div className="space-y-3">
        {items.map((item) => {
          const trend = trendStyles[item.trend];
          return (
            <div
              key={item.rank}
              className="flex items-center justify-between  border rounded-lg p-1 hover:shadow-sm"
            >
              {/* Left section: rank + name + category */}
              <div className="flex items-center gap-3">
                <span className="flex items-center justify-center w- h-5 rounded-full bg-yellow-100 text-yellow-700 font-bold text-sm">
                  #{item.rank}
                </span>
                <div>
                  <p className="font-medium text-gray-800">{item.name}</p>
                  <p className="text-sm text-gray-500">{item.category} • {item.sold} sold</p>
                </div>
              </div>

              {/* Right section: price + trend */}
              <div className="text-right">
                <p className="font-semibold">₹{item.amount.toLocaleString()}</p>
                <div
                  className={`inline-flex items-center gap-1 px-2 py-0.5 text-xs rounded-md ${trend.bg} ${trend.color}`}
                >
                  {trend.icon}
                  {item.trend === "stable" ? "Stable" : item.trend === "up" ? "Up" : "Down"}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TopSellingItems;

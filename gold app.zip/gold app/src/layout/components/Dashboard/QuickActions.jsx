import React from "react";

export default function QuickActions() {
  const actions = [
    { name: "Add New Item", onClick: () => alert("Add New Item clicked") },
    { name: "Create New Bill", onClick: () => alert("Create New Bill clicked") },
    { name: "Search Inventory", onClick: () => alert("Search Inventory clicked") },
  ];

  return (
    <div className="bg-white p-3 rounded-md shadow-sm w-full max-w-md">
      <h3 className="text-sm font-semibold mb-4 text-gray-700">Quick Actions</h3>
      <div className="flex gap-2">
        {actions.map((action) => (
          <button
            key={action.name}
            onClick={action.onClick}
            className="bg-yellow-500 text-white text-sm px-3 py-1.5 rounded-md hover:bg-yellow-600 transition w-full sm:w-auto"
          >
            {action.name}
          </button>
        ))}
      </div>
    </div>
  );
}

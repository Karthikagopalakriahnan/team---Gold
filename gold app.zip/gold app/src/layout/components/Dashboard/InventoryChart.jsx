import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Legend,
  Tooltip,
} from 'chart.js';

ChartJS.register(BarElement, CategoryScale, LinearScale, Legend, Tooltip);

const InventoryChart = () => {
  const data = {
    labels: ['Rings', 'Necklaces', 'Earrings', 'Bracelets', 'Chains'],
    datasets: [
      {
        label: 'Available',
        data: [45, 20, 70, 10, 35],
        backgroundColor: '#3b82f6', // Tailwind's blue-500
      },
      {
        label: 'Sold',
        data: [10, 5, 15, 8, 3],
        backgroundColor: '#f97316', // Tailwind's orange-500
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 20,
        },
      },
    },
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-4 max-w-md">
      <h2 className="text-xl font-semibold mb-4">Inventory Levels</h2>
      <div className="h-64">
        <Bar data={data} options={options} />
      </div>
    </div>
  );
};

export default InventoryChart;

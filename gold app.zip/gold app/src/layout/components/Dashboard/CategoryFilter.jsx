import { useState } from "react";

export default function CategoryFilter() {
  const [selectedCategory, setSelectedCategory] = useState("necklace");

  // Dummy category data
  const products = {
    necklace: [
      { id: 1, name: "Gold Necklace - Royal Design", price: "₹75,000" },
      { id: 2, name: "Gold Necklace - Simple Chain", price: "₹55,000" },
    ],
    ring: [
      { id: 3, name: "Gold Ring - Diamond Studded", price: "₹25,000" },
      { id: 4, name: "Gold Ring - Plain Band", price: "₹15,000" },
    ],
    chain: [
      { id: 5, name: "Gold Chain - Heavy", price: "₹65,000" },
      { id: 6, name: "Gold Chain - Light", price: "₹35,000" },
    ],
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow">
      <h2 className="text-xl font-semibold mb-4">Gold Inventory</h2>

      {/* Filter buttons */}
      <div className="flex space-x-4 mb-6">
        <button
          onClick={() => setSelectedCategory("necklace")}
          className={`px-4 py-2 rounded-lg ${
            selectedCategory === "necklace"
              ? "bg-yellow-500 text-white"
              : "bg-gray-200 text-gray-700"
          }`}
        >
          Necklace
        </button>
        <button
          onClick={() => setSelectedCategory("ring")}
          className={`px-4 py-2 rounded-lg ${
            selectedCategory === "ring"
              ? "bg-yellow-500 text-white"
              : "bg-gray-200 text-gray-700"
          }`}
        >
          Ring
        </button>
        <button
          onClick={() => setSelectedCategory("chain")}
          className={`px-4 py-2 rounded-lg ${
            selectedCategory === "chain"
              ? "bg-yellow-500 text-white"
              : "bg-gray-200 text-gray-700"
          }`}
        >
          Chain
        </button>
      </div>

      {/* Display products based on selected category */}
      <div className="space-y-3">
        {products[selectedCategory].map((item) => (
          <div
            key={item.id}
            className="p-4 border rounded-lg flex justify-between items-center hover:bg-gray-50"
          >
            <span className="text-gray-800">{item.name}</span>
            <span className="font-bold text-yellow-600">{item.price}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

import React from "react";
import { Calendar, ShoppingCart, Users, CreditCard } from "lucide-react";

const DailySummary = ({
  date,
  salesAchieved,
  salesTarget,
  ordersToday,
  customersServed,
  avgOrderValue,
  topCategory,
}) => {
  // calculate % progress
  const percentage = ((salesAchieved / salesTarget) * 100).toFixed(1);

  return (
    <div className="max-w-md w-full bg-white shadow-lg rounded-2xl p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Calendar className="text-yellow-600" />
          <h2 className="text-xl font-bold">Daily Summary</h2>
        </div>
        <span className="text-sm text-gray-500">{date}</span>
      </div>

      {/* Sales Target */}
      <div>
        <p className="text-gray-700 font-semibold">Sales Target</p>
        <div className="flex justify-between text-sm text-gray-500">
          <span>₹{salesAchieved.toLocaleString()} achieved</span>
          <span>₹{salesTarget.toLocaleString()} target</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-3 mt-2">
          <div
            className="bg-yellow-500 h-3 rounded-full text-right text-xs font-bold text-white pr-2"
            style={{ width: `${percentage}%` }}
          >
            {percentage}%
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1  gap-4">
        <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl">
          <div className="flex items-center space-x-2">
            <ShoppingCart className="text-blue-500" />
            <span className="font-medium">Orders Today</span>
          </div>
          <span className="font-bold">{ordersToday}</span>
        </div>

        <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl">
          <div className="flex items-center space-x-2">
            <Users className="text-green-600" />
            <span className="font-medium">Customers Served</span>
          </div>
          <span className="font-bold">{customersServed}</span>
        </div>

        <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-xl">
          <div className="flex items-center space-x-2">
            <CreditCard className="text-yellow-600" />
            <span className="font-medium">Avg Order Value</span>
          </div>
          <span className="font-bold">₹{avgOrderValue.toLocaleString()}</span>
        </div>
      </div>

      {/* Top Selling Category */}
      <div className="flex items-center justify-between">
        <p className="font-medium text-gray-700">Top Selling Category</p>
        <button className="px-3 py-1 text-sm bg-red-100 text-red-600 rounded-lg">
          {topCategory}
        </button>
      </div>
    </div>
  );
};

export default DailySummary;

export default function DashboardMetrics() {
  const metrics = [
    { label: 'Total Sales Today', value: '₹0' },
    { label: 'Active Inventory', value: '3 items' },
    { label: 'Bills Generated', value: '0' },
    { label: 'Total product', value: '5' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {metrics.map(({ label, value }) => (
        <div key={label} className="bg-white p-4 rounded shadow">
          <p className="text-sm text-gray-500">{label}</p>
          <p className="text-xl font-semibold">{value}</p>
        </div>
      ))}
    </div>
  );
}

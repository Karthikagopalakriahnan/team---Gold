import React from "react";
import { CreditCard, Wallet, Smartphone, CircleDollarSign } from "lucide-react";

const PaymentSummary = () => {
  const payments = [
    { label: "Cash", amount: 45000, percent: 65, icon: Wallet, color: "bg-green-500" },
    { label: "Card", amount: 18000, percent: 25, icon: CreditCard, color: "bg-blue-500" },
    { label: "UPI", amount: 7000, percent: 10, icon: Smartphone, color: "bg-purple-500" },
  ];

  const total = payments.reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4">Today's Payment Summary</h3>

      <div className="space-y-5">
        {payments.map((p, idx) => (
          <div key={idx}>
            {/* Row with icon, label, amount & percent */}
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <p.icon className={`w-5 h-5 text-gray-600`} />
                <span className="text-gray-700">{p.label}</span>
              </div>
              <div className="text-right">
                <p className="font-semibold">₹{p.amount.toLocaleString()}</p>
                <p className="text-sm text-gray-500">{p.percent}%</p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full h-2 bg-gray-200 rounded-full">
              <div
                className={`h-2 rounded-full ${p.color}`}
                style={{ width: `${p.percent}%` }}
              ></div>
            </div>
          </div>
        ))}

        {/* Total */}
        <div className="border-t pt-3 flex items-center justify-between">
          <div className="flex items-center gap-2 font-medium">
            <CircleDollarSign className="w-5 h-5 text-yellow-500" />
            <span>Total Revenue</span>
          </div>
          <p className="font-bold text-yellow-600">₹{total.toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
};

export default PaymentSummary;

import React from 'react';

const goldRates = [
  { type: '24K Gold', rate: '₹6,200/1gm' },
  { type: '22K Gold', rate: '₹5,850/1gm' },
  { type: '18K Gold', rate: '₹4,650/1gm' },
];

const GoldRates = () => {
  return (
    <div className="bg-white shadow-md rounded-lg p-6 w-full">
      <h2 className="text-xl font-semibold mb-4">Gold Rates</h2>
      <ul className="space-y-4">
        {goldRates.map((item, index) => (
          <li key={index} className="flex items-center justify-between">
            <span className="text-gray-700 font-medium">{item.type}</span>
            <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-semibold">
              {item.rate}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default GoldRates;

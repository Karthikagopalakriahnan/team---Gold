// src/components/WeeklySalesTrend.jsx
import React, { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const WeeklySalesTrend = () => {
  // Sample data
  const salesData = {
    thisWeek: [
      { day: "Mon", sales: 12000 },
      { day: "Tue", sales: 18000 },
      { day: "Wed", sales: 8000 },
      { day: "Thu", sales: 22000 },
      { day: "Fri", sales: 30000 },
      { day: "Sat", sales: 45000 },
      { day: "Sun", sales: 25000 },
    ],
    lastWeek: [
      { day: "Mon", sales: 10000 },
      { day: "Tue", sales: 15000 },
      { day: "Wed", sales: 12000 },
      { day: "Thu", sales: 20000 },
      { day: "Fri", sales: 25000 },
      { day: "Sat", sales: 35000 },
      { day: "Sun", sales: 20000 },
    ],
    CurrentMonth: [
      { day: "Mon", sales: 5000 },
      { day: "Tue", sales: 7000 },
      { day: "Wed", sales: 9000 },
      { day: "Thu", sales: 11000 },
      { day: "Fri", sales: 15000 },
      { day: "Sat", sales: 20000 },
      { day: "Sun", sales: 10000 },
    ],
  };

  const [filter, setFilter] = useState("thisWeek");

  return (
    <div className="mt-10 bg-white p-6 rounded-xl shadow-md w-full max-w-4xl mx-auto">
      {/* Header with Filter */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-xl font-bold">Weekly Sales Trend</h2>
        <select
          className="border border-gray-300 rounded-lg px-3 py-2 text-sm"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="thisWeek">This Week</option>
          <option value="lastWeek">Last Week</option>
          <option value="CurrentMonth">CurrentMonth</option>
        </select>
      </div>

      {/* Chart with no left/right gap */}
      <ResponsiveContainer width="100%" height={220}>
        <BarChart
          data={salesData[filter]}
          margin={{ top: 10, right: 0, left: 0, bottom: 0 }}
          barCategoryGap="0%"
          barGap={0}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="day" />
          <YAxis tickFormatter={(val) => `₹${val / 1000}k`} />
          <Tooltip formatter={(val) => [`₹${val}`, "Sales"]} />
          <Bar dataKey="sales" fill="#c79805" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default WeeklySalesTrend;

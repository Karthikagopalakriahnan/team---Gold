import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import html2pdf from "html2pdf.js";

// Async thunk to fetch customer data (mock implementation)
export const fetchCustomer = createAsyncThunk(
  "billing/fetchCustomer",
  async (customerId) => {
    return {
      id: customerId,
      name: "John Doe",
      phone: "9876543210",
      address: "123 Main St, Gold City",
      email: "john.doe@example.com",
    };
  }
);

// Async thunk to generate bill
export const generateBill = createAsyncThunk(
  "billing/generateBill",
  async (billData) => {
    console.log("Generating bill in Redux:", billData);
    return billData;
  }
);

// ✅ New async thunk: Save Draft & Download PDF
export const saveDraftPDF = createAsyncThunk(
  "billing/saveDraftPDF",
  async (_, { getState }) => {
    const state = getState().billing;
    const billData = state.bill.data;

    if (!billData) {
      throw new Error("No bill data found to save as draft");
    }

    // Find the BillPreview DOM node by id
    const element = document.getElementById("bill-preview");
    if (!element) {
      throw new Error("BillPreview element not found");
    }

    // Generate PDF
    const opt = {
      margin: 10,
      filename: `Draft_Bill_${billData.id || Date.now()}.pdf`,
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
    };

    await html2pdf().from(element).set(opt).save();

    return { ...billData, status: "draft" };
  }
);

const billingSlice = createSlice({
  name: "billing",
  initialState: {
    cart: { items: [] },
    customer: { data: {}, status: "idle", error: null },
    bill: { data: null, status: "idle", error: null },
    history: [],
  },
  reducers: {
    updateCustomer: (state, action) => {
      state.customer.data = action.payload;
    },
    clearCart: (state) => {
      state.cart.items = [];
      state.bill.data = null;
      state.bill.status = "idle";
    },
    addItemToCart: (state, action) => {
      state.cart.items.push(action.payload);
    },
    removeItemFromCart: (state, action) => {
      state.cart.items = state.cart.items.filter(
        (item) => item.id !== action.payload
      );
    },
    saveDraft: (state, action) => {
      console.log("Saving draft to history:", action.payload);
      state.history.push(action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCustomer.pending, (state) => {
        state.customer.status = "loading";
      })
      .addCase(fetchCustomer.fulfilled, (state, action) => {
        state.customer.status = "succeeded";
        state.customer.data = action.payload;
      })
      .addCase(fetchCustomer.rejected, (state, action) => {
        state.customer.status = "failed";
        state.customer.error = action.error.message;
      })
      .addCase(generateBill.pending, (state) => {
        state.bill.status = "loading";
      })
      .addCase(generateBill.fulfilled, (state, action) => {
        state.bill.status = "succeeded";
        state.bill.data = action.payload;
      })
      .addCase(generateBill.rejected, (state, action) => {
        state.bill.status = "failed";
        state.bill.error = action.error.message;
      })
      .addCase(saveDraftPDF.fulfilled, (state, action) => {
        state.history.push(action.payload); // Save draft in history
      });
  },
});

export const {
  updateCustomer,
  clearCart,
  addItemToCart,
  removeItemFromCart,
  saveDraft,
} = billingSlice.actions;

export default billingSlice.reducer;

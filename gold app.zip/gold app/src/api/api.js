import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:3001/api",
});

// ---- Customer APIs ----
export const getCustomer = (id) => API.get(`/customers/${id}`);
export const updateCustomer = (id, data) => API.put(`/customers/${id}`, data);

// ---- Bill APIs ----
export const getBills = () => API.get("/bills");
export const createBill = (data) => API.post("/bills", data);

// ---- Inventory APIs ----
export const getInventory = () => API.get("/inventory");
export const getInventoryItem = (id) => API.get(`/inventory/${id}`);
export const addInventoryItem = (data) => API.post("/inventory", data);
export const updateInventoryItem = (id, data) => API.put(`/inventory/${id}`, data);
export const deleteInventoryItem = (id) => API.delete(`/inventory/${id}`);

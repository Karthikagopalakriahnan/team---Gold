import React from "react";

const BillSummary = ({ subtotal, makingCharges, gst, total }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-lg font-semibold mb-4">Bill Summary</h2>

      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span>Subtotal (Base Value):</span>
          <span>₹{subtotal}</span>
        </div>
        <div className="flex justify-between">
          <span>Making Charges:</span>
          <span>₹{makingCharges}</span>
        </div>
        <div className="flex justify-between">
          <span>GST (3%):</span>
          <span>₹{gst}</span>
        </div>
        <div className="flex justify-between font-bold border-t pt-2">
          <span>Total Payable:</span>
          <span>₹{total}</span>
        </div>
      </div>
    </div>
  );
};

export default BillSummary;

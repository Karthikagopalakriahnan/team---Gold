// src/components/CartItems.jsx
import React, { useEffect, useRef, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { removeItemFromCart, addItemToCart } from "../redux/slices/BillingSlice";
import { Html5QrcodeScanner } from "html5-qrcode";
import { getInventory, addInventoryItem } from "../api/api"; // ✅ backend API

const CartItems = () => {
  const { cart: { items = [] } = {} } = useSelector((state) => state.billing);
  const dispatch = useDispatch();
  const scannerRef = useRef(null);
  const [scanning, setScanning] = useState(false);
  const [inventory, setInventory] = useState([]);
  const [newProduct, setNewProduct] = useState({
    id: "",
    productName: "",
    category: "",
    pricePerGram: "",
    stockQuantity: "",
  });

  // ✅ Fetch current inventory from backend
  const fetchInventory = async () => {
    try {
      const res = await getInventory();
      setInventory(res.data);
    } catch (err) {
      console.error("Error fetching inventory:", err);
    }
  };

  useEffect(() => {
    fetchInventory();
  }, []);

  // ✅ Add new product to backend DB
  const handleAddProduct = async () => {
    if (!newProduct.id || !newProduct.productName) {
      alert("Please fill all required fields.");
      return;
    }

    try {
      await addInventoryItem({
        id: newProduct.id,
        productName: newProduct.productName,
        category: newProduct.category || "General",
        supplier: "Local Supplier",
        weight: 5,
        purity: "22K",
        stockQuantity: Number(newProduct.stockQuantity) || 1,
        pricePerGram: Number(newProduct.pricePerGram),
        pricePerUnit: 0,
        makingCharge: 10,
        wastage: 5,
        sellingPrice: 0,
        lowStockAlert: 2,
        dateAdded: new Date().toLocaleDateString(),
      });
      alert("✅ Product added to database!");
      setNewProduct({ id: "", productName: "", category: "", pricePerGram: "", stockQuantity: "" });
      fetchInventory(); // refresh list
    } catch (err) {
      console.error("Error adding product:", err);
      alert("❌ Failed to add product!");
    }
  };

  // 🧠 Local cart management
  const handleAddItem = () => {
    dispatch(
      addItemToCart({
        id: Date.now(),
        name: "Gold Ring",
        price: 5000,
        quantity: 1,
      })
    );
  };

  // 🧾 Add backend item to cart
  const addBackendItemToCart = (item) => {
    dispatch(
      addItemToCart({
        id: item.id,
        name: item.productName,
        price: item.pricePerGram,
        quantity: 1,
      })
    );
  };

  // ✅ QR Scanner logic
  const startScan = () => {
    setScanning(true);
    if (!scannerRef.current) {
      scannerRef.current = new Html5QrcodeScanner("reader", {
        fps: 10,
        qrbox: 250,
      });

      scannerRef.current.render(
        (decodedText) => {
          console.log("Scanned result:", decodedText);
          handleScanSuccess(decodedText);
          stopScan();
        },
        (errorMessage) => {
          console.warn("Scan error:", errorMessage);
        }
      );
    }
  };

  const stopScan = () => {
    setScanning(false);
    if (scannerRef.current) {
      scannerRef.current.clear().then(() => {
        scannerRef.current = null;
      });
    }
  };

  const handleScanSuccess = (code) => {
    // 🧠 Lookup scanned item in inventory
    const found = inventory.find((i) => i.id === code);
    if (found) {
      addBackendItemToCart(found);
      alert(`✅ Added ${found.productName} to cart.`);
    } else {
      alert(`⚠️ Item with ID ${code} not found in inventory.`);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-4 relative">
      {/* Header with Add and Scan Buttons */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold">Cart Items</h2>

        <div className="flex gap-2">
          <button
            onClick={startScan}
            className="flex items-center gap-1 px-5 py-1 rounded bg-gray-500 text-white text-sm hover:bg-green-700 transition"
          >
            Scan
          </button>
          <button
            onClick={handleAddItem}
            className="flex items-center gap-1 rounded px-3 py-1 bg-blue-500 text-white text-sm hover:bg-blue-600 transition"
          >
            + Add Item
          </button>
        </div>
      </div>

      {/* QR Scanner */}
      {scanning && (
        <div className="mb-4 border p-2 rounded bg-gray-100">
          <div className="flex justify-between items-center mb-2">
            <p className="font-medium">
              Scanning... Point your barcode at the camera
            </p>
            <button
              onClick={stopScan}
              className="text-red-500 hover:underline text-sm"
            >
              Cancel
            </button>
          </div>
          <div id="reader" className="w-full max-w-md mx-auto"></div>
        </div>
      )}

      <hr className="w-full border-t border-gray-300 mb-4" />

      {/* ✅ New Product Form */}
      <div className="mb-6">
        <h3 className="font-medium mb-2">Add New Product to Inventory</h3>
        <div className="flex flex-wrap gap-2 mb-2">
          <input
            placeholder="ID"
            className="border p-1 rounded flex-1"
            value={newProduct.id}
            onChange={(e) => setNewProduct({ ...newProduct, id: e.target.value })}
          />
          <input
            placeholder="Product Name"
            className="border p-1 rounded flex-1"
            value={newProduct.productName}
            onChange={(e) => setNewProduct({ ...newProduct, productName: e.target.value })}
          />
          <input
            placeholder="Category"
            className="border p-1 rounded flex-1"
            value={newProduct.category}
            onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
          />
          <input
            placeholder="Price/Gram"
            type="number"
            className="border p-1 rounded flex-1"
            value={newProduct.pricePerGram}
            onChange={(e) => setNewProduct({ ...newProduct, pricePerGram: e.target.value })}
          />
          <input
            placeholder="Stock Quantity"
            type="number"
            className="border p-1 rounded flex-1"
            value={newProduct.stockQuantity}
            onChange={(e) => setNewProduct({ ...newProduct, stockQuantity: e.target.value })}
          />
        </div>
        <button
          onClick={handleAddProduct}
          className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700"
        >
          Add Product
        </button>
      </div>

      <hr className="w-full border-t border-gray-300 mb-4" />

      {/* 🧾 Backend Inventory Display */}
      <div className="mb-4">
        <h3 className="font-medium mb-2">Inventory Items</h3>
        {inventory.length === 0 ? (
          <p className="text-gray-500 italic">No items in inventory.</p>
        ) : (
          inventory.map((item) => (
            <div
              key={item.id}
              className="flex justify-between items-center border-b py-2"
            >
              <div>
                <h4 className="font-medium">{item.productName}</h4>
                <p className="text-sm text-gray-600">
                  ₹{item.pricePerGram} | Stock: {item.stockQuantity}
                </p>
              </div>
              <button
                onClick={() => addBackendItemToCart(item)}
                className="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600"
              >
                Add to Cart
              </button>
            </div>
          ))
        )}
      </div>

      <hr className="w-full border-t border-gray-300 mb-4" />

      {/* 🛒 Cart Section */}
      {items.length === 0 ? (
        <p className="text-gray-500 italic text-center py-4">
          No items in cart. Click <span className="font-medium">"Add Item"</span> or{" "}
          <span className="font-medium">"Scan"</span> to get started.
        </p>
      ) : (
        <div className="space-y-3">
          {items.map((item) => (
            <div
              key={item.id}
              className="flex justify-between items-center p-3 bg-gray-50 rounded border"
            >
              <div>
                <h3 className="font-medium">{item.name}</h3>
                <p className="text-sm text-gray-600">
                  ₹{item.price} × {item.quantity}
                </p>
              </div>
              <button
                onClick={() => dispatch(removeItemFromCart(item.id))}
                className="px-2 py-1 text-sm text-red-500 border border-red-500 rounded hover:bg-red-50"
              >
                Remove
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CartItems;

import React from "react";

const CustomerInfo = ({ onUpdate }) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h2 className="text-lg font-semibold mb-4">Customer Information</h2>

      <div className="space-y-4">
        {/* Name */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Name
          </label>
          <input
            type="text"
            placeholder="Enter customer name"
            onChange={(e) => onUpdate("name", e.target.value)}
            className="w-full p-2 border border-gray-200 rounded-md bg-blue-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Phone */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Phone
          </label>
          <input
            type="tel"
            placeholder="Enter phone number"
            onChange={(e) => onUpdate("phone", e.target.value)}
            className="w-full p-2 border border-gray-200 rounded-md bg-blue-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Address */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Address
          </label>
          <textarea
            placeholder="Enter address"
            onChange={(e) => onUpdate("address", e.target.value)}
            className="w-full p-2 border border-gray-200 rounded-md bg-blue-50 focus:outline-none focus:ring-2 focus:ring-blue-500 h-20 resize-none"
          />
        </div>

        {/* Email */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email (Optional)
          </label>
          <input
            type="email"
            placeholder="Enter email address"
            onChange={(e) => onUpdate("email", e.target.value)}
            className="w-full p-2 border border-gray-200 rounded-md bg-blue-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>
    </div>
  );
};

export default CustomerInfo;

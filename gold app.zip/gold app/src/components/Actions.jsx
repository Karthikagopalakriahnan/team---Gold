// src/components/Actions.js
import React from "react";

const Actions = ({
  onGenerate,
  onPrint,
  onClearCart,
  hasItems,
  billStatus,
  onSaveDraftPDF,
}) => {
  return (
    <div className="space-y-3">
      <hr className="w-full border-t border-gray-300 mb-4" />

      {/* Generate Bill */}
      <button
        onClick={() => {
          console.log("📄 Generate Bill clicked");
          onGenerate && onGenerate();
        }}
        disabled={!hasItems}
        className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-400 disabled:opacity-50"
      >
        📄 Generate Bill
      </button>

      {/* Save as Draft (PDF) */}
      <button
        onClick={() => {
          console.log("💾 Save as Draft (PDF) clicked");
          onSaveDraftPDF && onSaveDraftPDF();
        }}
        disabled={!hasItems}
        className="w-full bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-500 disabled:opacity-50"
      >
        💾 Save as PDF
      </button>

      {/* Print Bill */}
      <button
        onClick={() => {
          console.log("🖨️ Print Bill clicked");
          onPrint && onPrint();
        }}
        disabled={billStatus !== "succeeded"}
        className="w-full bg-yellow-400 text-white py-2 px-4 rounded hover:bg-yellow-300 disabled:opacity-50"
      >
        🖨️ Print Bill
      </button>

      {/* Clear Cart */}
      <button
        onClick={() => {
          console.log("🗑️ Clear Cart clicked");
          onClearCart && onClearCart();
        }}
        disabled={!hasItems}
        className="w-full bg-red-500 text-white py-2 px-4 rounded hover:bg-red-400 disabled:opacity-50"
      >
        🗑️ Clear Cart
      </button>
    </div>
  );
};

export default Actions;


import React from "react";

const BillHistoryModal = ({ isOpen, onClose, bills }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-white/30 backdrop-blur-sm">
      <div className="bg-white rounded-lg shadow-lg w-11/12 md:w-2/3 lg:w-1/2 p-6 relative">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-700 text-xl"
        >
          ✖
        </button>

        <h2 className="text-xl font-semibold mb-4">Bill History</h2>
        <hr className="mb-4" />

        {bills.length === 0 ? (
          <p className="text-gray-500 text-center">No bills found.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border border-gray-300 text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="border p-2">Bill ID</th>
                  <th className="border p-2">Date</th>
                  <th className="border p-2">Customer</th>
                  <th className="border p-2">Total</th>
                  <th className="border p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {bills.map((bill, i) => (
                  <tr key={i}>
                    <td className="border p-2">{bill.id}</td>
                    <td className="border p-2">{bill.date}</td>
                    <td className="border p-2">
                      {bill.customer?.name || "N/A"}
                    </td>
                    <td className="border p-2">₹{bill.total}</td>
                    <td className="border p-2">{bill.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default BillHistoryModal;

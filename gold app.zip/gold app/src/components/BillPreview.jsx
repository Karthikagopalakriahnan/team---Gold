import React, { forwardRef } from "react";
import { useSelector } from "react-redux";

const companyInfo = {
  name: "Golden Gems Jewelry",
  address: "123 Jewelry Street, Gold City, GC 12345",
  phone: "+91 98765 4321",
  gst: "27AABCU9032R1ZX",
};

const BillPreview = forwardRef(({ billData, subtotal, gst, total }, ref) => {
  const { cart, customer } = useSelector((state) => state.billing || {});
  const items = billData?.items || cart?.items || [];
  const customerData = customer?.data || billData?.customer || {};

  const currentDate = new Date().toLocaleDateString("en-IN");
  const currentTime = new Date().toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
  });

  // Debugging logs
  console.log("BillPreview rendering with props:", { billData, subtotal, gst, total });
  console.log("BillPreview state:", { cart, customer });

  return (
    <div
      ref={ref}
      id="bill-preview"
      style={{
        background: "#ffffff",
        borderRadius: "8px",
        boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
        padding: "24px",
        marginTop: "24px",
      }}
    >
      {/* Header */}
      <div style={{ textAlign: "center", marginBottom: "16px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: "bold", color: "#000000" }}>
          {companyInfo.name}
        </h2>
        <p style={{ fontSize: "14px", color: "#333333" }}>{companyInfo.address}</p>
        <p style={{ fontSize: "14px", color: "#333333" }}>
          Phone: {companyInfo.phone} | GST: {companyInfo.gst}
        </p>
      </div>

      {/* Bill + Customer */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "16px",
          fontSize: "14px",
          marginBottom: "16px",
        }}
      >
        <div>
          <strong style={{ color: "#000000" }}>Bill Details</strong>
          <br />
          ID: {billData?.id || `BILL-${Date.now()}`}
          <br />
          Date: {currentDate}
          <br />
          Time: {currentTime}
        </div>
        <div>
          <strong style={{ color: "#000000" }}>Customer Details</strong>
          <br />
          {customerData.name || "Customer Name"}
          <br />
          {customerData.phone || "Phone"}
          <br />
          {customerData.address || "Address"}
          <br />
          {customerData.email || "No Email Provided"}
        </div>
      </div>

      {/* Items */}
      <div style={{ overflowX: "auto" }}>
        <table
          style={{
            width: "100%",
            fontSize: "14px",
            border: "1px solid #dddddd",
            borderCollapse: "collapse",
          }}
        >
          <thead>
            <tr style={{ background: "#f7f7f7" }}>
              <th style={{ padding: "8px", border: "1px solid #dddddd" }}>SNO</th>
              <th style={{ padding: "8px", border: "1px solid #dddddd" }}>DESCRIPTION</th>
              <th style={{ padding: "8px", border: "1px solid #dddddd" }}>PCS</th>
              <th style={{ padding: "8px", border: "1px solid #dddddd" }}>PRICE</th>
              <th style={{ padding: "8px", border: "1px solid #dddddd" }}>AMOUNT</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td
                  colSpan="5"
                  style={{
                    padding: "16px",
                    textAlign: "center",
                    color: "#666666",
                  }}
                >
                  No items
                </td>
              </tr>
            ) : (
              items.map((item, i) => (
                <tr key={item.id || i}>
                  <td style={{ padding: "8px", border: "1px solid #dddddd" }}>{i + 1}</td>
                  <td style={{ padding: "8px", border: "1px solid #dddddd" }}>
                    {item.name || "Unknown Item"}
                  </td>
                  <td style={{ padding: "8px", border: "1px solid #dddddd" }}>
                    {item.quantity || 0}
                  </td>
                  <td style={{ padding: "8px", border: "1px solid #dddddd" }}>
                    ₹{(item.price || 0).toFixed(2)}
                  </td>
                  <td style={{ padding: "8px", border: "1px solid #dddddd" }}>
                    ₹{((item.price || 0) * (item.quantity || 0)).toFixed(2)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Totals */}
      <div style={{ marginTop: "16px", fontSize: "14px" }}>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span>Subtotal:</span>
          <span>₹{(subtotal || 0).toFixed(2)}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span>GST (3%):</span>
          <span>₹{(gst || 0).toFixed(2)}</span>
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            fontWeight: "bold",
            borderTop: "1px solid #dddddd",
            paddingTop: "8px",
            marginTop: "8px",
            fontSize: "16px",
          }}
        >
          <span>Total Payable:</span>
          <span>₹{(total || 0).toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
});

export default BillPreview;
import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchCustomer,
  updateCustomer,
  clearCart,
  generateBill,
  saveDraftPDF,
} from "../redux/slices/BillingSlice";
import CartItems from "./CartItems";
import CustomerInfo from "./CustomerInfo";
import BillPreview from "./BillPreview";
import Actions from "./Actions";
import BillHistoryModal from "./BillHistoryModal";

const BillingSystem = () => {
  const dispatch = useDispatch();
  const billRef = useRef();
  const [historyOpen, setHistoryOpen] = useState(false);

  const billingState = useSelector((state) => state.billing || {});
  const {
    cart: { items: cartItems = [] } = {},
    customer: { data: customerData = {} } = {},
    bill: { data: billData = null, status: billStatus = "idle" } = {},
    history = [],
  } = billingState;

  useEffect(() => {
    dispatch(fetchCustomer(1));
  }, [dispatch]);

  const handleUpdateCustomer = (field, value) => {
    dispatch(updateCustomer({ ...customerData, [field]: value }));
  };

  const subtotal = cartItems.reduce(
    (sum, item) => sum + (item.price || 0) * (item.quantity || 0),
    0
  );
  const gst = subtotal * 0.03;
  const total = subtotal + gst;

  const handleGenerateBill = async () => {
    if (cartItems.length === 0) {
      console.warn("No items in cart to generate bill");
      return;
    }

    const newBill = {
      id: `BILL-${Date.now()}`,
      customer: { ...customerData },
      items: [...cartItems],
      subtotal,
      gst,
      total,
      date: new Date().toLocaleDateString("en-IN"),
      status: "Generated",
    };

    try {
      await dispatch(generateBill(newBill)).unwrap();
      console.log("Bill generated successfully");
    } catch (error) {
      console.error("❌ Error generating bill:", error);
    }
  };

  const handleSaveDraftPDF = async () => {
    try {
      await dispatch(saveDraftPDF()).unwrap();
      console.log("Draft PDF saved successfully");
    } catch (error) {
      console.error("❌ Error generating PDF:", error);
    }
  };

  const handlePrint = () => {
    if (billRef.current) {
      const printContents = billRef.current.innerHTML;
      const newWindow = window.open("", "_blank");
      newWindow.document.write(`
        <html>
          <head>
            <title>Bill</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 20px; }
              h2, h3 { margin: 0; }
              .text-center { text-align: center; }
              .border { border: 1px solid #ddd; }
              .rounded { border-radius: 8px; }
              .p-6 { padding: 20px; }
            </style>
          </head>
          <body>${printContents}</body>
        </html>
      `);
      newWindow.document.close();
      newWindow.print();
      newWindow.close();
    } else {
      console.error("❌ BillPreview ref not found");
    }
  };

  const handleClearCart = () => {
    dispatch(clearCart());
  };

  return (
    <div className="max-w-7xl mx-auto">
      
      <div className="flex items-center justify-between mt-6 px-6">
        <h1 className="text-2xl font-bold text-gray-800">
          Gold Billing System
        </h1>
        <button
          onClick={() => setHistoryOpen(true)}
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded shadow"
        >
          📜 Bill History
        </button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mr-5 px-6 mt-6">
        <div className="lg:col-span-2 flex flex-col space-y-6">
          <CartItems />
          <BillPreview
            ref={billRef}
            billData={billData}
            subtotal={subtotal}
            gst={gst}
            total={total}
          />
        </div>
        <div className="lg:col-span-1 flex flex-col space-y-6">
          <CustomerInfo
            customerData={customerData}
            onUpdate={handleUpdateCustomer}
          />
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-2">Bill Summary</h2>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>₹{(subtotal || 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>GST (3%):</span>
                <span>₹{(gst || 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold border-t pt-2">
                <span>Total:</span>
                <span>₹{(total || 0).toFixed(2)}</span>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">Actions</h2>
            <Actions
              onGenerate={handleGenerateBill}
              onSaveDraftPDF={handleSaveDraftPDF}
              onClearCart={handleClearCart}
              hasItems={cartItems.length > 0}
              billStatus={billStatus}
              onPrint={handlePrint}
            />
          </div>
        </div>
      </div>
      <BillHistoryModal
        isOpen={historyOpen}
        onClose={() => setHistoryOpen(false)}
        bills={history}
      />
    </div>
  );
};

export default BillingSystem;
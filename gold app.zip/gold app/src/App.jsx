import React from "react";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { store, persistor } from "./redux/store";

// Core pages
import BillingSystem from "./components/BillingSystem";
import Inventory from "./layout/components/Inventory";
import Login from "./features/auth/pages/Login";
import AddItem from "./layout/components/AddItem";
import EditItem from "./layout/components/EditItem";
import DeleteItem from "./layout/components/DeleteItem";

// Shared layout
import Navbar from "./layout/components/Navbar";

// Dashboard sections
import DashboardMetrics from "./layout/components/Dashboard/DashboardMetrics";
import QuickActions from "./layout/components/Dashboard/QuickActions";
import RecentActivities from "./layout/components/Dashboard/RecentActivities";
import GoldRates from "./layout/components/Dashboard/GoldRates";
import InventoryChart from "./layout/components/Dashboard/InventoryChart";
import WeeklySalesTrend from "./layout/components/Dashboard/WeeklySalesTrend";
import PaymentSummary from "./layout/components/Dashboard/PaymentSummary";
import TopSellingItems from "./layout/components/Dashboard/TopSellingItems";

function App() {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <Router>
          <Navbar/>
          <Routes>
            {/* Auth */}
            <Route path="/" element={<Login />} />
            

            {/* Core pages */}
            <Route path="/billingsystem" element={<BillingSystem />} />
            <Route path="/billing" element={<BillingSystem />} />
            <Route path="/inventory" element={<Inventory />} />
            <Route path="/add-item" element={<AddItem />} />
            <Route path="/edit/:id" element={<EditItem />} />
            <Route path="/delete/:id" element={<DeleteItem />} />

            {/* Dashboard */}
            <Route
              path="/dashboard"
              element={
                <div className="min-h-screen bg-gray-100 flex flex-col">
                 
                  <main className="flex-1 p-6 space-y-6">
                    <DashboardMetrics />

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Left column */}
                      <div className="flex flex-col gap-6">
                        <QuickActions />
                        <GoldRates />
                        <RecentActivities />
                      </div>

                      {/* Right column */}
                      <div className="md:col-span-2 grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="h-60">
                          <InventoryChart />
                        </div>
                        <PaymentSummary />
                        <div className="lg:col-span-2">
                          <TopSellingItems />
                        </div>
                        <div className="lg:col-span-2">
                          <WeeklySalesTrend />
                        </div>
                      </div>
                    </div>
                  </main>
                </div>
              }
            />
          </Routes>
        </Router>
      </PersistGate>
    </Provider>
  );
}

export default App;

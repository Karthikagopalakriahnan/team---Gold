// backend/server.js
// ES Module (set "type": "module" in package.json)

import express from "express";
import sqlite3 from "sqlite3";
import cors from "cors";
import bodyParser from "body-parser";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));

// Initialize SQLite
const sqlite = sqlite3.verbose();
const DB_FILE = process.env.DB_PATH || path.join(__dirname, "goldshop.db");
const db = new sqlite.Database(DB_FILE, (err) => {
  if (err) {
    console.error("❌ Error opening DB:", err.message);
    process.exit(1);
  } else {
    console.log("✅ Connected to SQLite:", DB_FILE);
  }
});

// Utility: run SQL safely (promisified helper)
const runAsync = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });

const getAsync = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });

const allAsync = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });

// --------------------------------------------------
// Create tables (if not exists)
// --------------------------------------------------
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY,
      name TEXT,
      phone TEXT,
      address TEXT,
      email TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS bills (
      id TEXT PRIMARY KEY,
      customer TEXT,
      items TEXT,
      subtotal REAL,
      gst REAL,
      total REAL,
      date TEXT,
      status TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS inventory (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      barcode TEXT UNIQUE,
      productName TEXT,
      category TEXT,
      supplier TEXT,
      weight REAL,
      purity TEXT,
      stockQuantity INTEGER,
      pricePerGram REAL,
      pricePerUnit REAL,
      makingCharge REAL,
      wastage REAL,
      sellingPrice REAL,
      lowStockAlert INTEGER,
      dateAdded TEXT
    )
  `);
});

// --------------------------------------------------
// Helper: generate next GLD### barcode if none supplied
// --------------------------------------------------
async function generateNextBarcode() {
  try {
    // find last barcode like GLD###
    const row = await getAsync(
      `SELECT barcode FROM inventory WHERE barcode LIKE 'GLD%' ORDER BY id DESC LIMIT 1`
    );
    if (!row || !row.barcode) return "GLD001";
    const match = row.barcode.match(/GLD(\d+)/i);
    if (!match) return "GLD001";
    const next = parseInt(match[1], 10) + 1;
    return `GLD${String(next).padStart(3, "0")}`;
  } catch (err) {
    console.error("Error generating barcode:", err.message);
    return `GLD${Date.now().toString().slice(-6)}`;
  }
}

// --------------------------------------------------
// CUSTOMER ROUTES
// --------------------------------------------------
app.get("/api/customers/:id", async (req, res) => {
  try {
    const row = await getAsync("SELECT * FROM customers WHERE id = ?", [req.params.id]);
    if (!row) {
      const defaultCustomer = {
        id: parseInt(req.params.id),
        name: "John Doe",
        phone: "9876543210",
        address: "123 Main St, Gold City",
        email: "john.doe@example.com",
      };
      await runAsync(
        "INSERT INTO customers (id, name, phone, address, email) VALUES (?, ?, ?, ?, ?)",
        [defaultCustomer.id, defaultCustomer.name, defaultCustomer.phone, defaultCustomer.address, defaultCustomer.email]
      );
      return res.json(defaultCustomer);
    }
    res.json(row);
  } catch (err) {
    console.error("Customer GET error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

app.put("/api/customers/:id", async (req, res) => {
  try {
    const { name, phone, address, email } = req.body;
    await runAsync(
      "UPDATE customers SET name = ?, phone = ?, address = ?, email = ? WHERE id = ?",
      [name, phone, address, email, req.params.id]
    );
    res.json({ id: parseInt(req.params.id), name, phone, address, email });
  } catch (err) {
    console.error("Customer UPDATE error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// --------------------------------------------------
// BILLS ROUTES
// --------------------------------------------------
app.post("/api/bills", async (req, res) => {
  try {
    const { id, customer, items, subtotal, gst, total, date, status } = req.body;
    await runAsync(
      `INSERT INTO bills (id, customer, items, subtotal, gst, total, date, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, JSON.stringify(customer), JSON.stringify(items), subtotal, gst, total, date, status]
    );
    res.status(201).json(req.body);
  } catch (err) {
    console.error("Bills INSERT error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/bills", async (req, res) => {
  try {
    const rows = await allAsync("SELECT * FROM bills");
    const bills = rows.map((r) => ({ ...r, customer: JSON.parse(r.customer), items: JSON.parse(r.items) }));
    res.json(bills);
  } catch (err) {
    console.error("Bills GET error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// --------------------------------------------------
// CATEGORIES ROUTES
// --------------------------------------------------
app.post("/api/categories", async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: "Category name is required" });
    const result = await runAsync("INSERT INTO categories (name) VALUES (?)", [name]);
    res.status(201).json({ id: result.lastID, name });
  } catch (err) {
    if (err.message && err.message.includes("UNIQUE")) {
      return res.status(409).json({ error: "Category already exists" });
    }
    console.error("Category POST error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/categories", async (req, res) => {
  try {
    const rows = await allAsync("SELECT * FROM categories ORDER BY name ASC");
    res.json(rows);
  } catch (err) {
    console.error("Categories GET error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

app.delete("/api/categories/:id", async (req, res) => {
  try {
    const result = await runAsync("DELETE FROM categories WHERE id = ?", [req.params.id]);
    res.json({ deleted: result.changes || 0 });
  } catch (err) {
    console.error("Category DELETE error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// --------------------------------------------------
// INVENTORY ROUTES (match your AddItem.jsx)
// --------------------------------------------------

// Get all inventory
app.get("/api/inventory", async (req, res) => {
  try {
    const rows = await allAsync("SELECT * FROM inventory ORDER BY id DESC");
    res.json(rows);
  } catch (err) {
    console.error("Inventory GET error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// Get item by barcode
app.get("/api/inventory/:barcode", async (req, res) => {
  try {
    const row = await getAsync("SELECT * FROM inventory WHERE barcode = ?", [req.params.barcode]);
    res.json(row || null);
  } catch (err) {
    console.error("Inventory GET by barcode error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// Add item (auto-generate barcode if not provided)
app.post("/api/inventory", async (req, res) => {
  try {
    console.log("🟢 Received inventory POST:", req.body);

    // Accept either barcode or id keys for compatibility
    let { barcode, id: maybeId } = req.body;
    if (!barcode && maybeId) barcode = maybeId;

    const {
      productName,
      category = "General",
      supplier = "Local Supplier",
      weight = 0,
      purity = "",
      stockQuantity = 0,
      pricePerGram = 0,
      pricePerUnit = 0,
      makingCharge = 0,
      wastage = 0,
      sellingPrice = 0,
      lowStockAlert = 5,
      dateAdded,
    } = req.body;

    if (!productName) return res.status(400).json({ error: "productName is required" });

    // generate barcode if not supplied
    if (!barcode) barcode = await generateNextBarcode();

    const finalDate = dateAdded || new Date().toISOString().split("T")[0];

    await runAsync(
      `INSERT INTO inventory (
        barcode, productName, category, supplier, weight, purity,
        stockQuantity, pricePerGram, pricePerUnit, makingCharge, wastage,
        sellingPrice, lowStockAlert, dateAdded
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        barcode,
        productName,
        category,
        supplier,
        weight,
        purity,
        stockQuantity,
        pricePerGram,
        pricePerUnit,
        makingCharge,
        wastage,
        sellingPrice,
        lowStockAlert,
        finalDate,
      ]
    );

    const inserted = await getAsync("SELECT * FROM inventory WHERE barcode = ?", [barcode]);
    res.status(201).json(inserted);
  } catch (err) {
    console.error("Inventory POST error:", err.message);
    if (err.message && err.message.includes("UNIQUE")) {
      return res.status(409).json({ error: "Barcode already exists" });
    }
    res.status(500).json({ error: err.message });
  }
});

// Update item by barcode
app.put("/api/inventory/:barcode", async (req, res) => {
  try {
    const {
      productName,
      category,
      supplier,
      weight,
      purity,
      stockQuantity,
      pricePerGram,
      pricePerUnit,
      makingCharge,
      wastage,
      sellingPrice,
      lowStockAlert,
      dateAdded,
    } = req.body;

    const result = await runAsync(
      `
      UPDATE inventory SET
        productName = ?, category = ?, supplier = ?, weight = ?, purity = ?,
        stockQuantity = ?, pricePerGram = ?, pricePerUnit = ?, makingCharge = ?,
        wastage = ?, sellingPrice = ?, lowStockAlert = ?, dateAdded = ?
      WHERE barcode = ?
    `,
      [
        productName,
        category,
        supplier,
        weight,
        purity,
        stockQuantity,
        pricePerGram,
        pricePerUnit,
        makingCharge,
        wastage,
        sellingPrice,
        lowStockAlert,
        dateAdded,
        req.params.barcode,
      ]
    );

    res.json({ updated: result.changes || 0 });
  } catch (err) {
    console.error("Inventory PUT error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// Delete by barcode
app.delete("/api/inventory/:barcode", async (req, res) => {
  try {
    const result = await runAsync("DELETE FROM inventory WHERE barcode = ?", [req.params.barcode]);
    res.json({ deleted: result.changes || 0 });
  } catch (err) {
    console.error("Inventory DELETE error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// Low-stock filter
app.get("/api/inventory/low-stock", async (req, res) => {
  try {
    const rows = await allAsync("SELECT * FROM inventory WHERE stockQuantity <= lowStockAlert");
    res.json(rows);
  } catch (err) {
    console.error("Low-stock GET error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// --------------------------------------------------
// Graceful shutdown
// --------------------------------------------------
process.on("SIGINT", () => {
  console.log("🛑 Closing DB connection...");
  db.close((err) => {
    if (err) console.error("Error closing DB:", err.message);
    process.exit(0);
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Backend server running at http://localhost:${PORT}`);
});
